  -- phpMyAdmin SQL Dump
  -- version 5.2.1
  -- https://www.phpmyadmin.net/
  --
  -- Host: 127.0.0.1
  -- Generation Time: Apr 24, 2025 at 10:25 AM
  -- Wersja serwera: 10.4.32-MariaDB
  -- Wersja PHP: 8.2.12

  SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
  START TRANSACTION;
  SET time_zone = "+00:00";


  /*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
  /*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
  /*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
  /*!40101 SET NAMES utf8mb4 */;

  --
  -- Database: `wypozyczalnia_samochodow`
  --

  -- --------------------------------------------------------

  --
  -- Struktura tabeli dla tabeli `klienci`
  --

  CREATE TABLE `klienci` (
    `id_klienta` int(11) NOT NULL,  
    `imie` varchar(50) DEFAULT NULL,
    `nazwisko` varchar(50) DEFAULT NULL,
    `email` varchar(100) DEFAULT NULL,
    `telefon` varchar(20) DEFAULT NULL,
    `adres` text DEFAULT NULL,
    `data_rejestracji` date DEFAULT curdate()
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

  -- --------------------------------------------------------

  --
  -- Struktura tabeli dla tabeli `platnosci`
  --

  CREATE TABLE `platnosci` (
    `id_platnosci` int(11) NOT NULL,
    `id_wypozyczenia` int(11) DEFAULT NULL,
    `data_platnosci` date DEFAULT NULL,
    `kwota` decimal(10,2) DEFAULT NULL,
    `metoda_platnosci` enum('karta','gotówka','przelew','BLIK') DEFAULT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

  -- --------------------------------------------------------

  --
  -- Struktura tabeli dla tabeli `pracownicy`
  --

  CREATE TABLE `pracownicy` (
    `id_pracownika` int(11) NOT NULL,
    `imie` varchar(50) DEFAULT NULL,
    `nazwisko` varchar(50) DEFAULT NULL,
    `email` varchar(100) DEFAULT NULL,
    `stanowisko` varchar(50) DEFAULT NULL,
    `zatrudniony_od` date DEFAULT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

  -- --------------------------------------------------------

  --
  -- Struktura tabeli dla tabeli `samochody`
  --

  CREATE TABLE `samochody` (
    `id_samochodu` int(11) NOT NULL,
    `marka` varchar(50) DEFAULT NULL,
    `model` varchar(50) DEFAULT NULL,
    `rok_produkcji` int(11) DEFAULT NULL,
    `numer_rejestracyjny` varchar(20) DEFAULT NULL,
    `przebieg` int(11) DEFAULT NULL,
    `status` enum('dostępny','wypożyczony','serwis','zarezerwowany') DEFAULT 'dostępny',
    `cena_za_dzien` decimal(10,2) DEFAULT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

  -- --------------------------------------------------------

  --
  -- Struktura tabeli dla tabeli `wypozyczenia`
  --

  CREATE TABLE `wypozyczenia` (
    `id_wypozyczenia` int(11) NOT NULL,
    `id_klienta` int(11) DEFAULT NULL,
    `id_samochodu` int(11) DEFAULT NULL,
    `id_pracownika` int(11) DEFAULT NULL,
    `data_wypozyczenia` date DEFAULT NULL,
    `data_zwrotu` date DEFAULT NULL,
    `koszt_calkowity` decimal(10,2) DEFAULT NULL,
    `status` enum('aktywne','zakończone','anulowane') DEFAULT 'aktywne'
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

  --
  -- Indeksy dla zrzutów tabel
  --

  --
  -- Indeksy dla tabeli `klienci`
  --
  ALTER TABLE `klienci`
    ADD PRIMARY KEY (`id_klienta`);

  --
  -- Indeksy dla tabeli `platnosci`
  --
  ALTER TABLE `platnosci`
    ADD PRIMARY KEY (`id_platnosci`),
    ADD KEY `id_wypozyczenia` (`id_wypozyczenia`);

  --
  -- Indeksy dla tabeli `pracownicy`
  --
  ALTER TABLE `pracownicy`
    ADD PRIMARY KEY (`id_pracownika`);

  --
  -- Indeksy dla tabeli `samochody`
  --
  ALTER TABLE `samochody`
    ADD PRIMARY KEY (`id_samochodu`),
    ADD UNIQUE KEY `numer_rejestracyjny` (`numer_rejestracyjny`);

  --
  -- Indeksy dla tabeli `wypozyczenia`
  --
  ALTER TABLE `wypozyczenia`
    ADD PRIMARY KEY (`id_wypozyczenia`),
    ADD KEY `id_klienta` (`id_klienta`),
    ADD KEY `id_samochodu` (`id_samochodu`),
    ADD KEY `id_pracownika` (`id_pracownika`);

  --
  -- AUTO_INCREMENT for dumped tables
  --

  --
  -- AUTO_INCREMENT for table `klienci`
  --
  ALTER TABLE `klienci`
    MODIFY `id_klienta` int(11) NOT NULL AUTO_INCREMENT;

  --
  -- AUTO_INCREMENT for table `platnosci`
  --
  ALTER TABLE `platnosci`
    MODIFY `id_platnosci` int(11) NOT NULL AUTO_INCREMENT;

  --
  -- AUTO_INCREMENT for table `pracownicy`
  --
  ALTER TABLE `pracownicy`
    MODIFY `id_pracownika` int(11) NOT NULL AUTO_INCREMENT;

  --
  -- AUTO_INCREMENT for table `samochody`
  --
  ALTER TABLE `samochody`
    MODIFY `id_samochodu` int(11) NOT NULL AUTO_INCREMENT;

  --
  -- AUTO_INCREMENT for table `wypozyczenia`
  --
  ALTER TABLE `wypozyczenia`
    MODIFY `id_wypozyczenia` int(11) NOT NULL AUTO_INCREMENT;

  --
  -- Constraints for dumped tables
  --

  --
  -- Constraints for table `platnosci`
  --
  ALTER TABLE `platnosci`
    ADD CONSTRAINT `platnosci_ibfk_1` FOREIGN KEY (`id_wypozyczenia`) REFERENCES `wypozyczenia` (`id_wypozyczenia`);

  --
  -- Constraints for table `wypozyczenia`
  --
  ALTER TABLE `wypozyczenia`
    ADD CONSTRAINT `wypozyczenia_ibfk_1` FOREIGN KEY (`id_klienta`) REFERENCES `klienci` (`id_klienta`),
    ADD CONSTRAINT `wypozyczenia_ibfk_2` FOREIGN KEY (`id_samochodu`) REFERENCES `samochody` (`id_samochodu`),
    ADD CONSTRAINT `wypozyczenia_ibfk_3` FOREIGN KEY (`id_pracownika`) REFERENCES `pracownicy` (`id_pracownika`);
  COMMIT;

  /*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
  /*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
  /*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
