-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Cze 05, 2025 at 07:38 PM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wypozyczalnia_samochodow_wiktor_czechyra`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `klienci`
--

CREATE TABLE `klienci` (
  `id_klienta` int(11) NOT NULL,
  `imie` varchar(50) DEFAULT NULL,
  `nazwisko` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `adres` text DEFAULT NULL,
  `data_rejestracji` date DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `klienci`
--

INSERT INTO `klienci` (`id_klienta`, `imie`, `nazwisko`, `email`, `telefon`, `adres`, `data_rejestracji`) VALUES
(1, 'Jan', 'Kowalski', 'jan.kowalski@example.com', '506229243', 'ul. Szkolna 5, Wrocław', '2025-01-14'),
(2, 'Anna', 'Nowak', 'anna.nowak@example.com', '509789478', 'ul. Leśna 21, Gdańsk', '2025-02-28'),
(3, 'Marek', 'Wiśniewski', 'marek.wiśniewski@example.com', '503535719', 'ul. Szkolna 49, Warszawa', '2025-03-05'),
(4, 'Ewa', 'Mazur', 'ewa.mazur@example.com', '504776216', 'ul. Kwiatowa 39, Wrocław', '2025-04-18'),
(5, 'Tomasz', 'Zielińska', 'tomasz.zielińska@example.com', '506668398', 'ul. Leśna 10, Gdańsk', '2025-05-09'),
(6, 'Karolina', 'Kamiński', 'karolina.kamiński@example.com', '508128771', 'ul. Polna 2, Kraków', '2025-01-23'),
(7, 'Piotr', 'Wójcik', 'piotr.wójcik@example.com', '507105855', 'ul. Kwiatowa 35, Poznań', '2025-03-30'),
(8, 'Zofia', 'Krawczyk', 'zofia.krawczyk@example.com', '508825933', 'ul. Polna 21, Warszawa', '2025-02-11'),
(9, 'Adam', 'Dąbrowski', 'adam.dąbrowski@example.com', '503682355', 'ul. Polna 25, Wrocław', '2025-04-02'),
(10, 'Agnieszka', 'Lewandowski', 'agnieszka.lewandowski@example.com', '507489007', 'ul. Kwiatowa 2, Poznań', '2025-05-19');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `platnosci`
--

CREATE TABLE `platnosci` (
  `id_platnosci` int(11) NOT NULL,
  `id_wypozyczenia` int(11) DEFAULT NULL,
  `data_platnosci` date DEFAULT NULL,
  `kwota` decimal(10,2) DEFAULT NULL,
  `metoda_platnosci` enum('karta','gotówka','przelew','BLIK') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `platnosci`
--

INSERT INTO `platnosci` (`id_platnosci`, `id_wypozyczenia`, `data_platnosci`, `kwota`, `metoda_platnosci`) VALUES
(1, 1, '2025-05-31', 1286.00, 'przelew'),
(2, 2, '2025-05-27', 1245.00, 'gotówka'),
(3, 3, '2025-05-27', 1088.00, 'karta'),
(4, 4, '2025-06-01', 365.00, 'gotówka'),
(5, 5, '2025-05-27', 1094.00, 'gotówka'),
(6, 6, '2025-05-30', 838.00, 'BLIK'),
(7, 7, '2025-06-06', 304.00, 'gotówka'),
(8, 8, '2025-06-01', 417.00, 'gotówka'),
(9, 9, '2025-05-30', 589.00, 'gotówka'),
(10, 10, '2025-06-01', 1261.00, 'karta');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownicy`
--

CREATE TABLE `pracownicy` (
  `id_pracownika` int(11) NOT NULL,
  `imie` varchar(50) DEFAULT NULL,
  `nazwisko` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `stanowisko` varchar(50) DEFAULT NULL,
  `zatrudniony_od` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `pracownicy`
--

INSERT INTO `pracownicy` (`id_pracownika`, `imie`, `nazwisko`, `email`, `stanowisko`, `zatrudniony_od`) VALUES
(1, 'Jan', 'Lewandowski', 'jan.lewandowski@firma.pl', 'Konsultant', '2023-06-25'),
(2, 'Anna', 'Dąbrowski', 'anna.dąbrowski@firma.pl', 'Recepcjonista', '2021-12-26'),
(3, 'Marek', 'Krawczyk', 'marek.krawczyk@firma.pl', 'Recepcjonista', '2023-03-17'),
(4, 'Ewa', 'Wójcik', 'ewa.wójcik@firma.pl', 'Konsultant', '2021-06-18'),
(5, 'Tomasz', 'Kamiński', 'tomasz.kamiński@firma.pl', 'Konsultant', '2022-01-15'),
(6, 'Karolina', 'Zielińska', 'karolina.zielińska@firma.pl', 'Konsultant', '2021-01-15'),
(7, 'Piotr', 'Mazur', 'piotr.mazur@firma.pl', 'Mechanik', '2021-09-24'),
(8, 'Zofia', 'Wiśniewski', 'zofia.wiśniewski@firma.pl', 'Mechanik', '2023-06-26'),
(9, 'Adam', 'Nowak', 'adam.nowak@firma.pl', 'Recepcjonista', '2021-10-11'),
(10, 'Agnieszka', 'Kowalski', 'agnieszka.kowalski@firma.pl', 'Mechanik', '2021-08-11');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `samochody`
--

CREATE TABLE `samochody` (
  `id_samochodu` int(11) NOT NULL,
  `marka` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `rok_produkcji` int(11) DEFAULT NULL,
  `numer_rejestracyjny` varchar(20) DEFAULT NULL,
  `przebieg` int(11) DEFAULT NULL,
  `status` enum('dostępny','wypożyczony','serwis','zarezerwowany') DEFAULT 'dostępny',
  `cena_za_dzien` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `samochody`
--

INSERT INTO `samochody` (`id_samochodu`, `marka`, `model`, `rok_produkcji`, `numer_rejestracyjny`, `przebieg`, `status`, `cena_za_dzien`) VALUES
(1, 'Toyota', 'Corolla', 2018, 'WX41768', 116005, 'serwis', 158.00),
(2, 'BMW', 'X5', 2021, 'GD78289', 57079, 'zarezerwowany', 258.00),
(3, 'Fiat', 'Panda', 2021, 'KR12382', 51160, 'serwis', 181.00),
(4, 'Opel', 'Astra', 2021, 'PO80911', 89609, 'serwis', 182.00),
(5, 'Ford', 'Focus', 2021, 'PO36688', 64506, 'serwis', 141.00),
(6, 'Skoda', 'Octavia', 2022, 'KR63358', 107318, 'serwis', 205.00),
(7, 'Hyundai', 'i30', 2021, 'PO11436', 25249, 'serwis', 178.00),
(8, 'Kia', 'Ceed', 2019, 'WX77844', 107628, 'serwis', 132.00),
(9, 'Renault', 'Clio', 2022, 'WX94353', 78656, 'serwis', 194.00),
(10, 'Volkswagen', 'Golf', 2022, 'WX75298', 120457, 'serwis', 111.00);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wypozyczenia`
--

CREATE TABLE `wypozyczenia` (
  `id_wypozyczenia` int(11) NOT NULL,
  `id_klienta` int(11) DEFAULT NULL,
  `id_samochodu` int(11) DEFAULT NULL,
  `id_pracownika` int(11) DEFAULT NULL,
  `data_wypozyczenia` date DEFAULT NULL,
  `data_zwrotu` date DEFAULT NULL,
  `koszt_calkowity` decimal(10,2) DEFAULT NULL,
  `status` enum('aktywne','zakończone','anulowane') DEFAULT 'aktywne'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `wypozyczenia`
--

INSERT INTO `wypozyczenia` (`id_wypozyczenia`, `id_klienta`, `id_samochodu`, `id_pracownika`, `data_wypozyczenia`, `data_zwrotu`, `koszt_calkowity`, `status`) VALUES
(1, 4, 3, 10, '2025-05-12', NULL, NULL, 'aktywne'),
(2, 4, 10, 2, '2025-05-19', '2025-05-21', 1307.00, 'zakończone'),
(3, 10, 10, 6, '2025-05-07', '2025-05-11', 570.00, 'zakończone'),
(4, 9, 3, 2, '2025-05-04', '2025-05-11', 1352.00, 'zakończone'),
(5, 3, 2, 4, '2025-05-01', '2025-05-07', 388.00, 'zakończone'),
(6, 2, 2, 1, '2025-05-15', '2025-05-24', 877.00, 'zakończone'),
(7, 5, 2, 4, '2025-05-17', NULL, NULL, 'aktywne'),
(8, 6, 6, 4, '2025-05-07', '2025-05-13', 1374.00, 'zakończone'),
(9, 7, 3, 10, '2025-05-20', NULL, NULL, 'aktywne'),
(10, 6, 1, 3, '2025-05-10', '2025-05-12', 814.00, 'zakończone');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `klienci`
--
ALTER TABLE `klienci`
  ADD PRIMARY KEY (`id_klienta`);

--
-- Indeksy dla tabeli `platnosci`
--
ALTER TABLE `platnosci`
  ADD PRIMARY KEY (`id_platnosci`),
  ADD KEY `id_wypozyczenia` (`id_wypozyczenia`);

--
-- Indeksy dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD PRIMARY KEY (`id_pracownika`);

--
-- Indeksy dla tabeli `samochody`
--
ALTER TABLE `samochody`
  ADD PRIMARY KEY (`id_samochodu`),
  ADD UNIQUE KEY `numer_rejestracyjny` (`numer_rejestracyjny`);

--
-- Indeksy dla tabeli `wypozyczenia`
--
ALTER TABLE `wypozyczenia`
  ADD PRIMARY KEY (`id_wypozyczenia`),
  ADD KEY `id_klienta` (`id_klienta`),
  ADD KEY `id_samochodu` (`id_samochodu`),
  ADD KEY `id_pracownika` (`id_pracownika`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `klienci`
--
ALTER TABLE `klienci`
  MODIFY `id_klienta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `platnosci`
--
ALTER TABLE `platnosci`
  MODIFY `id_platnosci` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pracownicy`
--
ALTER TABLE `pracownicy`
  MODIFY `id_pracownika` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `samochody`
--
ALTER TABLE `samochody`
  MODIFY `id_samochodu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wypozyczenia`
--
ALTER TABLE `wypozyczenia`
  MODIFY `id_wypozyczenia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `platnosci`
--
ALTER TABLE `platnosci`
  ADD CONSTRAINT `platnosci_ibfk_1` FOREIGN KEY (`id_wypozyczenia`) REFERENCES `wypozyczenia` (`id_wypozyczenia`);

--
-- Constraints for table `wypozyczenia`
--
ALTER TABLE `wypozyczenia`
  ADD CONSTRAINT `wypozyczenia_ibfk_1` FOREIGN KEY (`id_klienta`) REFERENCES `klienci` (`id_klienta`),
  ADD CONSTRAINT `wypozyczenia_ibfk_2` FOREIGN KEY (`id_samochodu`) REFERENCES `samochody` (`id_samochodu`),
  ADD CONSTRAINT `wypozyczenia_ibfk_3` FOREIGN KEY (`id_pracownika`) REFERENCES `pracownicy` (`id_pracownika`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
